package com.anyaos.launcher

import android.content.Context
import android.view.KeyEvent
import android.view.View

class RemoteControlHelper(private val view: View) {

    interface OnDpadListener {
        fun onDpadUp(): Boolean
        fun onDpadDown(): Boolean
        fun onDpadLeft(): Boolean
        fun onDpadRight(): Boolean
        fun onEnter(): Boolean
        fun onBack(): Boolean
        fun onMenu(): Boolean
    }

    private var listener: OnDpadListener? = null

    fun setListener(listener: OnDpadListener) {
        this.listener = listener
    }

    fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> return listener?.onDpadUp() ?: false
            KeyEvent.KEYCODE_DPAD_DOWN -> return listener?.onDpadDown() ?: false
            KeyEvent.KEYCODE_DPAD_LEFT -> return listener?.onDpadLeft() ?: false
            KeyEvent.KEYCODE_DPAD_RIGHT -> return listener?.onDpadRight() ?: false
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER -> return listener?.onEnter() ?: false
            KeyEvent.KEYCODE_BACK -> return listener?.onBack() ?: false
            KeyEvent.KEYCODE_MENU -> return listener?.onMenu() ?: false
        }
        return false
    }
}
