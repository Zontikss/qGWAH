package com.anyaos.launcher

import android.graphics.drawable.Drawable
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

data class AppInfo(
    val packageName: String,
    val label: String,
    val icon: Drawable?,
    val version: String = "",
    val isSystem: Boolean = false,
    val isHidden: Boolean = false,
    val launchIntent: android.content.Intent? = null
) {
    companion object {
        fun fromApplicationInfo(info: ApplicationInfo, pm: PackageManager): AppInfo {
            val intent = pm.getLaunchIntentForPackage(info.packageName)
            return AppInfo(
                packageName = info.packageName,
                label = info.loadLabel(pm)?.toString() ?: info.packageName,
                icon = info.loadIcon(pm),
                version = try {
                    pm.getPackageInfo(info.packageName, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                },
                isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                isHidden = false,
                launchIntent = intent
            )
        }
    }
}
