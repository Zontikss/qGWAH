package com.anyaos.launcher

data class SettingItem(
    val title: String,
    val subtitle: String,
    val iconRes: Int,
    val action: String
)
