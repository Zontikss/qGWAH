package com.anyaos.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.StatFs
import java.util.*

/**
 * Enhanced app model with real launchable activity discovery, favorites,
 * ordering, and hide/unhide support. Hiding never disables or uninstalls
 * the package — it only removes it from AnyaOS's UI.
 */
data class AppModel(
    val packageName: String,
    val label: String,
    val icon: Drawable?,
    val launchIntent: Intent,
    val version: String = "",
    val isSystem: Boolean = false,
    var isFavorite: Boolean = false,
    var isHidden: Boolean = false,
    var displayOrder: Int = 0,
    var lastLaunched: Long = 0
)

object AppRepository {

    private const val PREF_NAME = "anyaos_apps"
    private const val KEY_FAVORITES = "favorite_packages"
    private const val KEY_HIDDEN = "hidden_packages"
    private const val KEY_ORDER = "app_order_"
    private const val KEY_LAST_LAUNCHED = "app_last_launched_"

    /**
     * Discovers all launchable applications using PackageManager.
     * Queries both CATEGORY_LEANBACK_LAUNCHER and CATEGORY_LAUNCHER,
     * deduplicates by package name, and only includes apps with a real
     * launchable Activity. Internal services and components without
     * launcher activities are excluded.
     */
    fun discoverApps(context: Context): List<AppModel> {
        val pm = context.packageManager
        val apps = mutableMapOf<String, AppModel>()

        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )

        for (intent in intents) {
            val resolveInfos: List<ResolveInfo> = pm.queryIntentActivities(intent, 0)
            for (ri in resolveInfos) {
                val activityInfo = ri.activityInfo
                if (activityInfo == null) continue
                val pkg = activityInfo.packageName

                // Skip the launcher itself and Android system packages
                if (pkg == context.packageName) continue
                if (pkg.startsWith("android.")) continue

                // Only include apps with an actual launchable intent
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent == null) continue

                val label = activityInfo.loadLabel(pm)?.toString() ?: pkg
                val icon: Drawable? = try {
                    activityInfo.loadIcon(pm)
                } catch (e: Exception) {
                    null
                }

                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val isFavorite = prefs.getBoolean(KEY_FAVORITES + pkg, false)
                val isHidden = prefs.getBoolean(KEY_HIDDEN + pkg, false)
                val order = prefs.getInt(KEY_ORDER + pkg, 0)
                val lastLaunched = prefs.getLong(KEY_LAST_LAUNCHED + pkg, 0)

                val version = try {
                    pm.getPackageInfo(pkg, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }

                val isSystem = (activityInfo.applicationInfo.flags and
                    android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0

                apps[pkg] = AppModel(
                    packageName = pkg,
                    label = label,
                    icon = icon,
                    launchIntent = launchIntent,
                    version = version,
                    isSystem = isSystem,
                    isFavorite = isFavorite,
                    isHidden = isHidden,
                    displayOrder = order,
                    lastLaunched = lastLaunched
                )
            }
        }

        // Sort: favorites first (by displayOrder), then by label
        return apps.values.sortedWith(
            compareBy({ !it.isFavorite }, { it.displayOrder }, { it.label.lowercase() })
        )
    }

    /**
     * Returns only non-hidden apps (for display in the UI).
     */
    fun getVisibleApps(context: Context): List<AppModel> {
        return discoverApps(context).filterNot { it.isHidden }
    }

    /**
     * Returns only favorite apps (for the favorites row).
     */
    fun getFavoriteApps(context: Context): List<AppModel> {
        return discoverApps(context).filter { it.isFavorite && !it.isHidden }
    }

    /**
     * Returns only hidden apps (for the hidden apps management page).
     */
    fun getHiddenApps(context: Context): List<AppModel> {
        return discoverApps(context).filter { it.isHidden }
    }

    fun toggleFavorite(context: Context, app: AppModel) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val newValue = !app.isFavorite
        prefs.edit().putBoolean(KEY_FAVORITES + app.packageName, newValue).apply()
    }

    fun toggleHidden(context: Context, app: AppModel) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val newValue = !app.isHidden
        prefs.edit().putBoolean(KEY_HIDDEN + app.packageName, newValue).apply()
    }

    fun setDisplayOrder(context: Context, app: AppModel, order: Int) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_ORDER + app.packageName, order).apply()
    }

    fun recordLaunch(context: Context, app: AppModel) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putLong(KEY_LAST_LAUNCHED + app.packageName, System.currentTimeMillis()).apply()
    }

    fun getRecentlyLaunched(context: Context, limit: Int = 6): List<AppModel> {
        val all = discoverApps(context)
        return all.sortedByDescending { it.lastLaunched }
            .filter { it.lastLaunched > 0 && !it.isHidden }
            .take(limit)
    }

    /**
     * System information for the Settings > System page.
     */
    data class SystemInfo(
        val model: String,
        val manufacturer: String,
        val androidVersion: String,
        val sdkInt: Int,
        val buildId: String,
        val totalRamMb: Long,
        val availableRamMb: Long,
        val totalStorageGb: Long,
        val availableStorageGb: Long,
        val anyaosVersion: String
    )

    fun getSystemInfo(context: Context): SystemInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val statFs = StatFs(context.externalCacheDir?.path ?: context.cacheDir.path)
        val totalBytes = statFs.totalBytes.toLong()
        val availableBytes = statFs.availableBytes.toLong()

        val packageName = context.packageName
        val anyaosVersion = try {
            context.packageManager.getPackageInfo(packageName, 0).versionName ?: "0.3.0"
        } catch (e: Exception) {
            "0.3.0"
        }

        return SystemInfo(
            model = Build.MODEL,
            manufacturer = Build.MANUFACTURER,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            buildId = Build.ID,
            totalRamMb = memInfo.totalMem / (1024 * 1024),
            availableRamMb = memInfo.availMem / (1024 * 1024),
            totalStorageGb = totalBytes / (1024 * 1024 * 1024),
            availableStorageGb = availableBytes / (1024 * 1024 * 1024),
            anyaosVersion = anyaosVersion
        )
    }
}
