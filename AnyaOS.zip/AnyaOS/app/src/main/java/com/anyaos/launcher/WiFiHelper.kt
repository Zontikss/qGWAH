package com.anyaos.launcher

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.wifi.WifiManager

object WiFiHelper {

    enum class WiFiState {
        DISABLED,
        ENABLED_DISCONNECTED,
        CONNECTED_NO_INTERNET,
        CONNECTED_WITH_INTERNET
    }

    data class WiFiInfo(
        val state: WiFiState,
        val ssid: String? = null,
        val isConnected: Boolean = false,
        val hasInternet: Boolean = false
    )

    fun getWiFiInfo(context: Context): WiFiInfo {
        val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val isWifiEnabled = wifiManager.isWifiEnabled
        if (!isWifiEnabled) {
            return WiFiInfo(state = WiFiState.DISABLED, isConnected = false, hasInternet = false)
        }

        val wifiInfo = wifiManager.connectionInfo
        val ssid = wifiInfo?.ssid?.replace("\"", "")

        val networkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
        val isConnected = networkInfo?.isConnectedOrConnecting ?: false

        if (!isConnected) {
            return WiFiInfo(state = WiFiState.ENABLED_DISCONNECTED, ssid = ssid, isConnected = false, hasInternet = false)
        }

        // Check for internet connectivity
        val activeNetwork = connectivityManager.activeNetworkInfo
        val hasInternet = activeNetwork?.isConnectedOrConnecting ?: false

        val state = if (hasInternet) WiFiState.CONNECTED_WITH_INTERNET else WiFiState.CONNECTED_NO_INTERNET

        return WiFiInfo(state = state, ssid = ssid, isConnected = true, hasInternet = hasInternet)
    }

    fun getStateDescription(state: WiFiState): String = when (state) {
        WiFiState.DISABLED -> "Wi-Fi выключен"
        WiFiState.ENABLED_DISCONNECTED -> "Отключено"
        WiFiState.CONNECTED_NO_INTERNET -> "Подключено, нет интернета"
        WiFiState.CONNECTED_WITH_INTERNET -> "Подключено к интернету"
    }

    fun getStateColorRes(state: WiFiState): Int = when (state) {
        WiFiState.DISABLED -> R.color.wifi_disabled
        WiFiState.ENABLED_DISCONNECTED -> R.color.wifi_disconnected
        WiFiState.CONNECTED_NO_INTERNET -> R.color.wifi_disconnected
        WiFiState.CONNECTED_WITH_INTERNET -> R.color.wifi_connected
    }

    fun getIconRes(state: WiFiState): Int = when (state) {
        WiFiState.DISABLED -> R.drawable.ic_wifi_disabled
        WiFiState.ENABLED_DISCONNECTED -> R.drawable.ic_wifi_disconnected
        WiFiState.CONNECTED_NO_INTERNET -> R.drawable.ic_wifi_disconnected
        WiFiState.CONNECTED_WITH_INTERNET -> R.drawable.ic_wifi_connected
    }
}
