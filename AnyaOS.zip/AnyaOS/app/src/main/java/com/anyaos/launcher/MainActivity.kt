package com.anyaos.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), RemoteControlHelper.OnDpadListener {

    private lateinit var remoteHelper: RemoteControlHelper
    private var currentSection: String = ""
    private lateinit var contentArea: FrameLayout
    private lateinit var quickPanel: FrameLayout
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var greetingView: TextView
    private lateinit var wifiIcon: ImageView
    private lateinit var wifiStatusText: TextView
    private lateinit var wifiStatusContainer: RelativeLayout
    private lateinit var bluetoothIcon: ImageView
    private lateinit var bluetoothStatusText: TextView

    private var isQuickPanelOpen = false
    private var wifiPollHandler: Handler? = null
    private var wifiPollRunnable: Runnable? = null

    private val ACTION_APPEARANCE = "appearance"
    private val ACTION_APPLICATIONS = "applications"
    private val ACTION_DISPLAY = "display"
    private val ACTION_SOUND = "sound"
    private val ACTION_NETWORK = "network"
    private val ACTION_SYSTEM = "system"
    private val ACTION_MAINTENANCE = "maintenance"

    override fun onCreate(savedInstanceState: Bundle?) {
        val theme = ThemeManager.loadTheme(this)
        ThemeManager.applyTheme(this, theme)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        remoteHelper = RemoteControlHelper(findViewById(android.R.id.content))
        remoteHelper.setListener(this)

        contentArea = findViewById(R.id.content_area)
        quickPanel = findViewById(R.id.quick_panel)
        clockView = findViewById(R.id.clock_view)
        dateView = findViewById(R.id.date_view)
        greetingView = findViewById(R.id.greeting_view)
        wifiIcon = findViewById(R.id.wifi_icon)
        wifiStatusText = findViewById(R.id.wifi_status_text)
        wifiStatusContainer = findViewById(R.id.wifi_status_container)
        bluetoothIcon = findViewById(R.id.bluetooth_icon)
        bluetoothStatusText = findViewById(R.id.bluetooth_status_text)

        setupTopBarClicks()
        setupWiFiStatusClick()
        setupBluetoothClick()
        startClock()
        startWiFiPolling()
        updateBluetoothStatus()

        navigateToHome()
    }

    private fun setupTopBarClicks() {
        findViewById<ImageView>(R.id.btn_nav_home).setOnClickListener { navigateToHome() }
        findViewById<ImageView>(R.id.btn_nav_apps).setOnClickListener { navigateToApps() }
        findViewById<ImageView>(R.id.btn_nav_sources).setOnClickListener { navigateToSources() }
        findViewById<ImageView>(R.id.btn_nav_settings).setOnClickListener { navigateToSettings() }
        findViewById<ImageButton>(R.id.btn_quick_settings).setOnClickListener { toggleQuickPanel() }
    }

    private fun setupWiFiStatusClick() {
        wifiStatusContainer.setOnClickListener { toggleQuickPanel() }
    }

    private fun setupBluetoothClick() {
        bluetoothIcon.setOnClickListener { toggleQuickPanel() }
        bluetoothStatusText.setOnClickListener { toggleQuickPanel() }
    }

    private fun startClock() {
        val handler = Handler(Looper.getMainLooper())
        handler.post(object : Runnable {
            override fun run() {
                updateClock()
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun updateClock() {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateSdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        val now = Date()
        clockView.text = sdf.format(now)
        dateView.text = dateSdf.format(now)
        val calendar = Calendar.getInstance()
        calendar.time = now
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        greetingView.text = when {
            hour in 5 until 12 -> getString(R.string.greeting_morning)
            hour in 12 until 18 -> getString(R.string.greeting_day)
            else -> getString(R.string.greeting_evening)
        }
    }

    private fun startWiFiPolling() {
        wifiPollHandler = Handler(Looper.getMainLooper())
        wifiPollRunnable = object : Runnable {
            override fun run() {
                updateWiFiStatus()
                wifiPollHandler?.postDelayed(this, 5000)
            }
        }
        wifiPollHandler?.post(wifiPollRunnable)
    }

    private fun updateWiFiStatus() {
        val wifiInfo = WiFiHelper.getWiFiInfo(this)
        wifiIcon.setImageResource(WiFiHelper.getIconRes(wifiInfo.state))
        wifiStatusText.text = WiFiHelper.getStateDescription(wifiInfo.state)
        wifiStatusText.setTextColor(resources.getColor(WiFiHelper.getStateColorRes(wifiInfo.state)))
    }

    private fun updateBluetoothStatus() {
        val btAdapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
        if (btAdapter == null) {
            bluetoothIcon.visibility = View.GONE
            bluetoothStatusText.visibility = View.GONE
            return
        }
        val enabled = btAdapter.isEnabled
        bluetoothIcon.setImageResource(if (enabled) R.drawable.ic_bluetooth_on else R.drawable.ic_bluetooth_off)
        bluetoothStatusText.text = if (enabled) getString(R.string.bluetooth_on) else getString(R.string.bluetooth_off)
    }

    fun navigateToHome() {
        currentSection = "home"
        if (findViewById<View>(R.id.home_root) == null) {
            val homeView = buildHomeScreen()
            homeView.id = R.id.home_root
            switchView(homeView)
        } else {
            switchView(findViewById<View>(R.id.home_root))
        }
        updateTopBarHighlight("home")
    }

    fun navigateToApps() {
        currentSection = "apps"
        if (findViewById<View>(R.id.apps_root) == null) {
            val appsView = buildAppsScreen()
            appsView.id = R.id.apps_root
            switchView(appsView)
        } else {
            switchView(findViewById<View>(R.id.apps_root))
        }
        updateTopBarHighlight("apps")
    }

    fun navigateToSources() {
        currentSection = "sources"
        if (findViewById<View>(R.id.sources_root) == null) {
            val sourcesView = buildSourcesScreen()
            sourcesView.id = R.id.sources_root
            switchView(sourcesView)
        } else {
            switchView(findViewById<View>(R.id.sources_root))
        }
        updateTopBarHighlight("sources")
    }

    fun navigateToSettings() {
        currentSection = "settings"
        if (findViewById<View>(R.id.settings_root) == null) {
            val settingsView = buildSettingsScreen()
            settingsView.id = R.id.settings_root
            switchView(settingsView)
        } else {
            switchView(findViewById<View>(R.id.settings_root))
        }
        updateTopBarHighlight("settings")
    }

    private fun switchView(view: View) {
        contentArea.removeAllViews()
        contentArea.addView(view)
    }

    private fun updateTopBarHighlight(active: String) {
        val navIds = mapOf(
            "home" to R.id.btn_nav_home,
            "apps" to R.id.btn_nav_apps,
            "sources" to R.id.btn_nav_sources,
            "settings" to R.id.btn_nav_settings
        )
        navIds.forEach { (tag, id) ->
            val view = findViewById<ImageButton>(id)
            view.setBackgroundResource(if (tag == active) R.drawable.bg_card_focused else R.drawable.bg_nav_button)
        }
    }

    private fun toggleQuickPanel() {
        isQuickPanelOpen = !isQuickPanelOpen
        quickPanel.visibility = if (isQuickPanelOpen) View.VISIBLE else View.GONE
        if (isQuickPanelOpen) {
            buildQuickPanel()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        return remoteHelper.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event)
    }

    override fun onDpadUp(): Boolean {
        val focus = currentFocus
        if (focus != null) {
            focus.focusSearch(View.FOCUS_UP)?.requestFocus()
        }
        return true
    }

    override fun onDpadDown(): Boolean {
        val focus = currentFocus
        if (focus != null) {
            focus.focusSearch(View.FOCUS_DOWN)?.requestFocus()
        }
        return true
    }

    override fun onDpadLeft(): Boolean {
        val focus = currentFocus
        if (focus != null) {
            focus.focusSearch(View.FOCUS_LEFT)?.requestFocus()
        }
        return true
    }

    override fun onDpadRight(): Boolean {
        val focus = currentFocus
        if (focus != null) {
            focus.focusSearch(View.FOCUS_RIGHT)?.requestFocus()
        }
        return true
    }

    override fun onEnter(): Boolean {
        val focus = currentFocus
        if (focus != null) {
            focus.performClick()
        }
        return true
    }

    override fun onBack(): Boolean {
        if (isQuickPanelOpen) {
            toggleQuickPanel()
            return true
        }
        if (currentSection != "") {
            navigateToHome()
            return true
        }
        return false
    }

    override fun onMenu(): Boolean {
        navigateToSettings()
        return true
    }

    override fun onDestroy() {
        wifiPollHandler?.removeCallbacks(wifiPollRunnable)
        super.onDestroy()
    }

    // ========================================================================
    // HOME SCREEN
    // ========================================================================

    private fun buildHomeScreen(): View {
        val root = LinearLayout(this)
        root.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundResource(0) // inherit theme background

        // Hero section
        val heroFrame = FrameLayout(this)
        heroFrame.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            resources.getDimensionPixelSize(R.dimen.hero_height)
        )
        heroFrame.setBackgroundResource(R.drawable.bg_hero)

        val heroTitle = TextView(this)
        heroTitle.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        heroTitle.text = getString(R.string.hero_title)
        heroTitle.setTextAppearance(R.style.TextAppearance_AnyaOS_Display)
        heroTitle.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        heroFrame.addView(heroTitle)

        val heroSubtitle = TextView(this)
        heroSubtitle.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        heroSubtitle.text = getString(R.string.hero_subtitle)
        heroSubtitle.setTextAppearance(R.style.TextAppearance_AnyaOS_Body)
        heroSubtitle.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        heroFrame.addView(heroSubtitle)

        root.addView(heroFrame)

        // Favorites section
        val favsLabel = sectionLabel(R.string.featured_apps)
        root.addView(favsLabel)

        val favsRow = HorizontalScrollView(this)
        favsRow.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            resources.getDimensionPixelSize(R.dimen.app_card_height) + resources.getDimensionPixelSize(R.dimen.margin_large) * 2
        )
        favsRow.isFillViewport = false

        val favsContainer = LinearLayout(this)
        favsContainer.orientation = LinearLayout.HORIZONTAL
        favsContainer.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            0,
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium)
        )

        val favoriteApps = AppRepository.getFavoriteApps(this)
        if (favoriteApps.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.no_favorites)
            empty.setTextAppearance(R.style.TextAppearance_AnyaOS_Small)
            empty.setPadding(resources.getDimensionPixelSize(R.dimen.margin_medium), 0, 0, 0)
            favsContainer.addView(empty)
        } else {
            for (app in favoriteApps) {
                val card = buildAppCard(app, isFavorite = true)
                favsContainer.addView(card)
            }
        }
        favsRow.addView(favsContainer)
        root.addView(favsRow)

        // Customization & Themes carousel
        val themesLabel = sectionLabel(R.string.customization_themes)
        root.addView(themesLabel)

        val themeCarousel = HorizontalScrollView(this)
        themeCarousel.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            resources.getDimensionPixelSize(R.dimen.theme_card_height) + resources.getDimensionPixelSize(R.dimen.margin_large) * 2
        )
        themeCarousel.isFillViewport = false

        val themeContainer = LinearLayout(this)
        themeContainer.orientation = LinearLayout.HORIZONTAL
        themeContainer.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            0,
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium)
        )

        val currentTheme = ThemeManager.loadTheme(this)
        for (theme in ThemeManager.getAllThemes()) {
            val card = buildThemeCard(theme, isSelected = theme.id == currentTheme.id)
            themeContainer.addView(card)
        }
        themeCarousel.addView(themeContainer)
        root.addView(themeCarousel)

        // Recent apps section
        val recentLabel = sectionLabel(R.string.recent_apps)
        root.addView(recentLabel)

        val recentRow = HorizontalScrollView(this)
        recentRow.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            resources.getDimensionPixelSize(R.dimen.app_card_height) + resources.getDimensionPixelSize(R.dimen.margin_large) * 2
        )
        recentRow.isFillViewport = false

        val recentContainer = LinearLayout(this)
        recentContainer.orientation = LinearLayout.HORIZONTAL
        recentContainer.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            0,
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium)
        )

        val recentApps = AppRepository.getRecentlyLaunched(this, 6)
        if (recentApps.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.no_recent_apps)
            empty.setTextAppearance(R.style.TextAppearance_AnyaOS_Small)
            empty.setPadding(resources.getDimensionPixelSize(R.dimen.margin_medium), 0, 0, 0)
            recentContainer.addView(empty)
        } else {
            for (app in recentApps) {
                val card = buildAppCard(app, isFavorite = false)
                recentContainer.addView(card)
            }
        }
        recentRow.addView(recentContainer)
        root.addView(recentRow)

        return root
    }

    private fun sectionLabel(resId: Int): TextView {
        val label = TextView(this)
        label.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        label.text = getString(resId)
        label.setTextAppearance(R.style.TextAppearance_AnyaOS_Headline)
        label.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.section_spacing),
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            0
        )
        return label
    }

    private fun buildAppCard(app: AppModel, isFavorite: Boolean): View {
        val card = layoutInflater.inflate(R.layout.item_app_card_focusable, null)
        val icon: ImageView = card.findViewById(R.id.item_app_icon)
        val name: TextView = card.findViewById(R.id.item_app_name)
        val star: ImageView = card.findViewById(R.id.item_app_star)

        icon.setImageDrawable(app.icon)
        name.text = app.label
        name.setTextAppearance(R.style.TextAppearance_AnyaOS_Body)
        star.setImageResource(if (isFavorite) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        star.setColorFilter(resources.getColor(R.color.default_primary))

        card.setOnClickListener {
            AppRepository.recordLaunch(this, app)
            app.launchIntent?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(it)
            }
        }

        card.setOnLongClickListener {
            showAppContextMenu(app)
            true
        }

        return card
    }

    private fun buildThemeCard(theme: ThemeManager.AnyaTheme, isSelected: Boolean): View {
        val card = layoutInflater.inflate(R.layout.item_theme_preview_card, null)
        val preview: ImageView = card.findViewById(R.id.item_theme_preview)
        val name: TextView = card.findViewById(R.id.item_theme_name)
        val desc: TextView = card.findViewById(R.id.item_theme_desc)
        val check: ImageView = card.findViewById(R.id.item_theme_check)

        preview.setImageResource(getThemePreviewRes(theme))
        name.text = ThemeManager.getThemeName(theme)
        name.setTextAppearance(R.style.TextAppearance_AnyaOS_Title)
        desc.text = getThemeDescription(theme)
        desc.setTextAppearance(R.style.TextAppearance_AnyaOS_Small)

        check.visibility = if (isSelected) View.VISIBLE else View.GONE
        check.setImageResource(R.drawable.ic_check)
        check.setColorFilter(resources.getColor(R.color.theme_primary))

        card.setOnClickListener {
            ThemeManager.applyTheme(this@MainActivity, theme)
            recreate()
        }

        return card
    }

    private fun getThemePreviewRes(theme: ThemeManager.AnyaTheme): Int = when (theme) {
        ThemeManager.AnyaTheme.DEFAULT_DARK -> R.drawable.preview_default_dark
        ThemeManager.AnyaTheme.FROST -> R.drawable.preview_frost
        ThemeManager.AnyaTheme.GITHUB_DARK -> R.drawable.preview_github_dark
        ThemeManager.AnyaTheme.SAKURA -> R.drawable.preview_sakura
    }

    private fun getThemeDescription(theme: ThemeManager.AnyaTheme): String = when (theme) {
        ThemeManager.AnyaTheme.DEFAULT_DARK -> getString(R.string.theme_desc_default)
        ThemeManager.AnyaTheme.FROST -> getString(R.string.theme_desc_frost)
        ThemeManager.AnyaTheme.GITHUB_DARK -> getString(R.string.theme_desc_github)
        ThemeManager.AnyaTheme.SAKURA -> getString(R.string.theme_desc_sakura)
    }

    private fun showAppContextMenu(app: AppModel) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(app.label)

        val isFav = AppRepository.getFavoriteApps(this).any { it.packageName == app.packageName }
        val items = mutableListOf<String>()
        items.add(if (isFav) getString(R.string.unpin) else getString(R.string.pin))
        if (app.isHidden) {
            items.add(getString(R.string.unhide))
        } else {
            items.add(getString(R.string.hide))
        }
        items.add(getString(R.string.launch))
        items.add(getString(R.string.app_info))

        builder.setItems(items.toTypedArray()) { _, which ->
            when (which) {
                0 -> {
                    AppRepository.toggleFavorite(this, app)
                    navigateToHome()
                }
                1 -> {
                    if (app.isHidden) {
                        AppRepository.toggleHidden(this, app)
                    } else {
                        AppRepository.toggleHidden(this, app)
                    }
                    navigateToHome()
                }
                2 -> {
                    AppRepository.recordLaunch(this, app)
                    app.launchIntent?.let {
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        startActivity(it)
                    }
                }
                3 -> showAppInfo(app)
            }
        }

        builder.setNegativeButton(R.string.cancel) { _, _ -> }
        builder.show()
    }

    private fun showAppInfo(app: AppModel) {
        val builder = AlertDialog.Builder(this)
        val sb = StringBuilder()
        sb.append(getString(R.string.app_name_label)).append(": ").append(app.label).append("\n")
        sb.append(getString(R.string.package_name_label)).append(": ").append(app.packageName).append("\n")
        sb.append(getString(R.string.version_label)).append(": ").append(if (app.version.isNotEmpty()) app.version else getString(R.string.unknown)).append("\n")
        sb.append(getString(R.string.system_app_label)).append(": ").append(if (app.isHidden) getString(R.string.hidden_in_anyaos) else getString(R.string.visible_in_anyaos)).append("\n")
        builder.setTitle(getString(R.string.app_info))
        builder.setMessage(sb.toString())
        builder.setPositiveButton(R.string.ok) { _, _ -> }
        builder.show()
    }

    // ========================================================================
    // APPS SCREEN
    // ========================================================================

    private fun buildAppsScreen(): View {
        val root = LinearLayout(this)
        root.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.orientation = LinearLayout.VERTICAL

        val label = sectionLabel(R.string.apps_title)
        root.addView(label)

        val scroll = ScrollView(this)
        scroll.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        scroll.isFillViewport = true

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            0,
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium)
        )

        val visibleApps = AppRepository.getVisibleApps(this)
        if (visibleApps.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.no_apps)
            empty.setTextAppearance(R.style.TextAppearance_AnyaOS_Body)
            empty.setPadding(resources.getDimensionPixelSize(R.dimen.margin_medium), 0, 0, 0)
            container.addView(empty)
        } else {
            for (app in visibleApps) {
                val row = buildAppListRow(app)
                container.addView(row)
            }
        }

        scroll.addView(container)
        root.addView(scroll)
        return root
    }

    private fun buildAppListRow(app: AppModel): View {
        val row = LinearLayout(this)
        row.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            resources.getDimensionPixelSize(R.dimen.setting_card_height)
        )
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_small),
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_small)
        )
        row.setBackgroundResource(R.drawable.bg_setting_card)
        row.isFocusable = true
        row.isClickable = true

        val icon = ImageView(this)
        icon.layoutParams = ViewGroup.LayoutParams(
            resources.getDimensionPixelSize(R.dimen.app_icon_size) / 2,
            resources.getDimensionPixelSize(R.dimen.app_icon_size) / 2
        )
        icon.setImageDrawable(app.icon)
        row.addView(icon)

        val info = LinearLayout(this)
        val infoParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT)
        infoParams.weight = 1f
        info.layoutParams = infoParams
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(resources.getDimensionPixelSize(R.dimen.margin_medium), 0, 0, 0)

        val name = TextView(this)
        name.text = app.label
        name.setTextAppearance(R.style.TextAppearance_AnyaOS_Body)
        info.addView(name)

        val pkg = TextView(this)
        pkg.text = app.packageName
        pkg.setTextAppearance(R.style.TextAppearance_AnyaOS_Caption)
        info.addView(pkg)
        row.addView(info)

        val launchBtn = Button(this)
        launchBtn.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        launchBtn.text = getString(R.string.launch)
        launchBtn.setOnClickListener {
            AppRepository.recordLaunch(this, app)
            app.launchIntent?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(it)
            }
        }
        row.addView(launchBtn)

        row.setOnClickListener {
            AppRepository.recordLaunch(this, app)
            app.launchIntent?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(it)
            }
        }

        return row
    }

    // ========================================================================
    // SOURCES SCREEN
    // ========================================================================

    private fun buildSourcesScreen(): View {
        val root = LinearLayout(this)
        root.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER

        val label = TextView(this)
        label.text = "Источники"
        label.setTextAppearance(R.style.TextAppearance_AnyaOS_Headline)
        root.addView(label)

        return root
    }

    // ========================================================================
    // SETTINGS SCREEN
    // ========================================================================

    private fun buildSettingsScreen(): View {
        val root = ScrollView(this)
        root.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.isFillViewport = true

        val container = LinearLayout(this)
        container.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium)
        )

        val title = TextView(this)
        title.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        title.text = getString(R.string.settings_title)
        title.setTextAppearance(R.style.TextAppearance_AnyaOS_Display)
        title.setPadding(0, 0, 0, resources.getDimensionPixelSize(R.dimen.margin_large))
        container.addView(title)

        val settingItems = listOf(
            SettingItem(getString(R.string.section_appearance), getString(R.string.theme_selector), R.drawable.ic_theme, ACTION_APPEARANCE),
            SettingItem(getString(R.string.section_applications), getString(R.string.installed_apps), R.drawable.ic_apps, ACTION_APPLICATIONS),
            SettingItem(getString(R.string.section_network), getString(R.string.network_info), R.drawable.ic_wifi_connected, ACTION_NETWORK),
            SettingItem(getString(R.string.section_display), getString(R.string.display_settings), R.drawable.ic_display, ACTION_DISPLAY),
            SettingItem(getString(R.string.section_sound), getString(R.string.sound_settings), R.drawable.ic_sound, ACTION_SOUND),
            SettingItem(getString(R.string.section_system), getString(R.string.device_info), R.drawable.ic_system, ACTION_SYSTEM),
            SettingItem(getString(R.string.section_maintenance), getString(R.string.maintenance), R.drawable.ic_maintenance, ACTION_MAINTENANCE)
        )

        for (item in settingItems) {
            val card = layoutInflater.inflate(R.layout.item_setting_card, container, false)
            val icon: ImageView = card.findViewById(R.id.item_setting_icon)
            val titleView: TextView = card.findViewById(R.id.item_setting_title)
            val subtitle: TextView = card.findViewById(R.id.item_setting_subtitle)

            icon.setImageResource(item.iconRes)
            titleView.text = item.title
            titleView.setTextAppearance(R.style.TextAppearance_AnyaOS_Body)
            subtitle.text = item.subtitle
            subtitle.setTextAppearance(R.style.TextAppearance_AnyaOS_Small)

            card.setOnClickListener {
                handleSettingAction(item.action)
            }

            container.addView(card)
        }

        root.addView(container)
        return root
    }

    private fun handleSettingAction(action: String) {
        when (action) {
            ACTION_APPEARANCE -> showThemeSelector()
            ACTION_APPLICATIONS -> navigateToApps()
            ACTION_DISPLAY -> openSystemSettings()
            ACTION_SOUND -> openSystemSettings()
            ACTION_NETWORK -> toggleQuickPanel()
            ACTION_SYSTEM -> showSystemInfo()
            ACTION_MAINTENANCE -> showMaintenanceInfo()
        }
    }

    // ========================================================================
    // THEME SELECTOR
    // ========================================================================

    private fun showThemeSelector() {
        val themes = ThemeManager.getAllThemes()
        val currentTheme = ThemeManager.loadTheme(this)

        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.theme_selector))

        val dialogView = layoutInflater.inflate(R.layout.dialog_theme_selector, null)
        val carousel = dialogView.findViewById<HorizontalScrollView>(R.id.theme_carousel)
        val themeContainer = LinearLayout(this)
        themeContainer.orientation = LinearLayout.HORIZONTAL
        themeContainer.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_small),
            0,
            resources.getDimensionPixelSize(R.dimen.margin_small),
            0
        )

        for (theme in themes) {
            val card = layoutInflater.inflate(R.layout.item_theme_preview_card, themeContainer, false)
            val preview: ImageView = card.findViewById(R.id.item_theme_preview)
            val name: TextView = card.findViewById(R.id.item_theme_name)
            val desc: TextView = card.findViewById(R.id.item_theme_desc)
            val check: ImageView = card.findViewById(R.id.item_theme_check)

            preview.setImageResource(getThemePreviewRes(theme))
            name.text = ThemeManager.getThemeName(theme)
            name.setTextAppearance(R.style.TextAppearance_AnyaOS_Title)
            desc.text = getThemeDescription(theme)
            desc.setTextAppearance(R.style.TextAppearance_AnyaOS_Small)

            if (theme.id == currentTheme.id) {
                check.visibility = View.VISIBLE
            }

            card.setOnClickListener {
                ThemeManager.applyTheme(this@MainActivity, theme)
                recreate()
                builder.create().dismiss()
            }

            themeContainer.addView(card)
        }
        carousel.addView(themeContainer)
        builder.setView(dialogView)

        builder.setPositiveButton(R.string.apply) { _, _ -> }
        builder.setNegativeButton(R.string.cancel_theme) { _, _ -> }
        builder.show()
    }

    // ========================================================================
    // SYSTEM ACTIONS
    // ========================================================================

    private fun openSystemSettings() {
        val intent = Intent(android.provider.Settings.ACTION_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            val fallback = Intent(android.provider.Settings.ACTION_SETTINGS)
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(fallback)
        }
    }

    private fun showSystemInfo() {
        val info = AppRepository.getSystemInfo(this)
        val sb = StringBuilder()
        sb.append(getString(R.string.device_model)).append(": ").append(info.model).append("\n")
        sb.append(getString(R.string.manufacturer)).append(": ").append(info.manufacturer).append("\n")
        sb.append(getString(R.string.android_version)).append(": ").append(info.androidVersion).append(" (SDK ").append(info.sdkInt).append(")\n")
        sb.append(getString(R.string.firmware_info)).append(": ").append(info.buildId).append("\n")
        sb.append(getString(R.string.memory)).append(": ").append(info.availableRamMb).append(" МБ свободно из ").append(info.totalRamMb).append(" МБ\n")
        sb.append(getString(R.string.storage)).append(": ").append(info.availableStorageGb).append(" ГБ свободно из ").append(info.totalStorageGb).append(" ГБ\n")
        sb.append(getString(R.string.anyao_version)).append(": ").append(info.anyaosVersion).append("\n")

        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.device_info))
        builder.setMessage(sb.toString())
        builder.setPositiveButton(R.string.ok) { _, _ -> }
        builder.show()
    }

    private fun showMaintenanceInfo() {
        val info = AppRepository.getSystemInfo(this)
        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.maintenance))
        val sb = StringBuilder()
        sb.append(getString(R.string.app_count)).append(": ").append(AppRepository.discoverApps(this).size).append("\n")
        sb.append(getString(R.string.memory)).append(": ").append(info.availableRamMb).append(" / ").append(info.totalRamMb).append(" МБ\n")
        sb.append(getString(R.string.storage)).append(": ").append(info.availableStorageGb).append(" / ").append(info.totalStorageGb).append(" ГБ\n")
        sb.append(getString(R.string.anyaos_version)).append(": 0.3.0\n")
        sb.append("\n")
        sb.append(getString(R.string.rollback_instructions))
        builder.setMessage(sb.toString())
        builder.setPositiveButton(R.string.ok) { _, _ -> }
        builder.show()
    }

    private fun buildQuickPanel() {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium),
            resources.getDimensionPixelSize(R.dimen.margin_medium)
        )

        val header = TextView(this)
        header.text = getString(R.string.quick_panel)
        header.setTextAppearance(R.style.TextAppearance_AnyaOS_Headline)
        header.setPadding(0, 0, 0, resources.getDimensionPixelSize(R.dimen.margin_medium))
        panel.addView(header)

        // Wi-Fi tile
        val wifiTile = layoutInflater.inflate(R.layout.panel_tile_wifi, panel, false)
        panel.addView(wifiTile)

        // Bluetooth tile
        val btTile = layoutInflater.inflate(R.layout.panel_tile_bluetooth, panel, false)
        panel.addView(btTile)

        // System tile
        val sysTile = layoutInflater.inflate(R.layout.panel_tile_system, panel, false)
        panel.addView(sysTile)

        // Maintenance tile
        val maintTile = layoutInflater.inflate(R.layout.panel_tile_maintenance, panel, false)
        panel.addView(maintTile)

        quickPanel.removeAllViews()
        quickPanel.addView(panel)

        wifiTile.setOnClickListener { toggleQuickPanel() }
        btTile.setOnClickListener { toggleQuickPanel() }
        sysTile.setOnClickListener { showSystemInfo() }
        maintTile.setOnClickListener { showMaintenanceInfo() }
    }

}

