package com.anyaos.launcher

import android.content.Context
import android.content.SharedPreferences

object ThemeManager {

    internal const val PREF_NAME = "anyaos_settings"
    private const val KEY_THEME = "selected_theme"

    enum class AnyaTheme(
        val id: Int,
        val displayName: String,
        val styleRes: Int,
        val bgColor: Int,
        val surfaceColor: Int,
        val primaryColor: Int,
        val secondaryColor: Int
    ) {
        DEFAULT_DARK(0, "Default Dark", R.style.Theme_AnyaOS_DefaultDark,
            R.color.default_background, R.color.default_surface,
            R.color.default_primary, R.color.default_secondary),
        FROST(1, "Frost", R.style.Theme_AnyaOS_Frost,
            R.color.frost_background, R.color.frost_surface,
            R.color.frost_primary, R.color.frost_secondary),
        GITHUB_DARK(2, "GitHub Dark", R.style.Theme_AnyaOS_GitHubDark,
            R.color.github_background, R.color.github_surface,
            R.color.github_primary, R.color.github_secondary),
        SAKURA(3, "Sakura", R.style.Theme_AnyaOS_Sakura,
            R.color.sakura_background, R.color.sakura_surface,
            R.color.sakura_primary, R.color.sakura_secondary)
    }

    private var currentTheme: AnyaTheme = AnyaTheme.DEFAULT_DARK

    fun getCurrentTheme(): AnyaTheme = currentTheme

    fun setTheme(context: Context, theme: AnyaTheme) {
        currentTheme = theme
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(KEY_THEME, theme.id)
            .apply()
    }

    fun loadTheme(context: Context): AnyaTheme {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val themeId = prefs.getInt(KEY_THEME, AnyaTheme.DEFAULT_DARK.id)
        return AnyaTheme.values().firstOrNull { it.id == themeId } ?: AnyaTheme.DEFAULT_DARK
    }

    fun getThemeName(theme: AnyaTheme): String = theme.displayName

    fun applyTheme(context: Context, theme: AnyaTheme) {
        setTheme(context, theme)
        context.setTheme(theme.styleRes)
    }

    fun getAllThemes(): Array<AnyaTheme> = AnyaTheme.values()
}
